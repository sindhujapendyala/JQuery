$('#submit-button').click(function() {
    $('#user_text').text($('#username').val());
    $('#pass_text').text($('#password').val());
    $('#email_text').text($('#email').val());
});